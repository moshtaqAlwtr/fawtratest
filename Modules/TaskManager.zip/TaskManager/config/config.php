<?php

return [
    'name' => 'TaskManager',
];
