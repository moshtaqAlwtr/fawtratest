<div id="mapContainer" class="map-hidden">
    <div id="map"></div>
    <div class="pac-card">
        <div class="search-container">
            <input type="text" id="clientSearch" class="search-box" placeholder="ابحث عن عميل..." style="margin-left: 100px">
            <i class="fas fa-search search-icon"></i>
        </div>
    </div>
    <button id="fullscreenButton" class="map-fullscreen-button" title="تكبير/تصغير الشاشة">
        <i class="fas fa-expand"></i>
    </button>
</div>
